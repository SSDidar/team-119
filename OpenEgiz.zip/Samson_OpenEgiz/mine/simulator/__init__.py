"""Samson mine simulation package."""
